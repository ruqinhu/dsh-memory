import Schema from '@deepseek-ai/schemastery';
export interface Config {
    memoryCap: number;
    userCap: number;
    enableInjection: boolean;
    backupKeep: number;
    memoryDir: string;
    enableRecall: boolean;
    recallBudgetChars: number;
}
/**
 * Caps default to the values the inherited Hermes deployment settled on
 * (`weekly_memory_compact.py`: MEMORY.md 2200, USER.md 1375). They are
 * configuration so a deployment can raise them while the inherited files are
 * being compressed, then lower them back.
 */
export declare const Config: Schema<Config>;
