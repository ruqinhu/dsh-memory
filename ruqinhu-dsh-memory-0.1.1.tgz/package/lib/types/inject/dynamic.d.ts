import type { Context } from '@deepseek-ai/cordis';
import type { MemoryFiles } from '../store/files.js';
/**
 * Threshold past which a document is injected as a pointer to the retrieval tool
 * instead of in full.
 *
 * Below it, inlining is strictly better: the text is cheaper than a tool round
 * trip and the model always has the rules in view. Above it, inlining would
 * crowd out working context, so the model is told to search instead.
 */
export declare const INLINE_BUDGET_CHARS = 6000;
/**
 * Placement among dynamic contexts.
 *
 * The harness orders contexts as working directory (100), sandbox policy (110),
 * approval policy (115), subagent delegation (120), team identity (125), then
 * harness source (200). Memory is deployment identity, so it sits just after the
 * team slot.
 */
export declare const MEMORY_CONTEXT_ORDER = 130;
export interface DynamicOptions {
    enabled: boolean;
}
/**
 * Register a dynamic context carrying the memory documents.
 *
 * This uses `systemPrompt.context()` rather than `agent/pre-step` on purpose.
 * The context seam is documented as "dynamic model context materialized as a
 * durable user-role snapshot", and its `text` provider is re-evaluated at
 * assembly and admission refresh — exactly the semantics memory needs. Injecting
 * through `agent/pre-step` would instead require fabricating an identified
 * `UserMessage` on every step, which misrepresents memory as user input and makes
 * the plugin mint message ids the harness never issued.
 *
 * Documents that fit the inline budget are injected whole; larger ones are
 * represented by an entry index plus a pointer to `memory_search`, so a growing
 * memory never silently displaces working context.
 */
export declare function installDynamicInjection(ctx: Context, files: MemoryFiles, options: DynamicOptions): void;
