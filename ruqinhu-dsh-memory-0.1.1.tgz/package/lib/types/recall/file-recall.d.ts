/**
 * The raw documents recall reads from.
 *
 * Structurally identical to `MemoryFiles.read`, but narrower on purpose: recall only
 * needs to read, and a seam that cannot write cannot corrupt anything.
 */
export interface RecallSource {
    memory: string;
    user: string;
}
export interface RecallResult {
    /** Text to prepend to the turn, or `''` when nothing relevant was found. */
    block: string;
    /**
     * One short line stating what was recalled, e.g. `🧠 召回 2 条记忆`, or `''`.
     *
     * This exists so the operator can SEE that memory was consulted. Hermes learnt the
     * same lesson (`describe_recall`): without a deterministic indicator, a silent model
     * and a broken recall path are indistinguishable — the same failure this deployment
     * already had with delivery.
     */
    indicator: string;
}
export interface RecallOptions {
    /** Hard ceiling on injected characters. Recall cost is paid on every turn. */
    budgetChars?: number;
}
/** Default ceiling: comfortably below the 6000-char inline budget for the documents. */
export declare const DEFAULT_RECALL_BUDGET = 1500;
/**
 * Keyword recall over the plain-file documents.
 *
 * One implementation, not an abstraction over many: a service interface with a single
 * adapter would be a hypothetical seam, and the cost of the indirection is paid now
 * while the variation it anticipates may never arrive. If a second backend is ever
 * added, this shape is what it will have to satisfy.
 *
 * Scoring is delegated to `scoreEntries`, which counts matching query terms and
 * already handles CJK runs without splitting them per character.
 */
export declare class FileRecall {
    private readonly source;
    private readonly budgetChars;
    constructor(source: RecallSource, options?: RecallOptions);
    /**
     * Pick the entries worth injecting for `query`.
     *
     * Entries are taken highest-score first until the budget is spent, so a broad query
     * that matches half the document still yields the most specific entries rather than
     * an arbitrary prefix. An entry that does not fit the remaining budget is skipped
     * rather than truncated: half a rule is worse than no rule, because it reads as
     * complete.
     */
    prefetch(query: string): RecallResult;
    /** Score every entry from both documents, best first, dropping zero scores. */
    private rank;
}
