import type { Context } from '@deepseek-ai/cordis';
import type { MemoryFiles } from './store/files.js';
export interface ToolDeps {
    files: MemoryFiles;
    caps: {
        memory: number;
        user: number;
    };
    backupKeep: number;
    /** When true, register `memory_recall` alongside the search tool. */
    enableRecall?: boolean;
    /** Character ceiling for one recall, threaded through to {@link FileRecall}. */
    recallBudgetChars?: number;
}
export declare function registerTools(ctx: Context, deps: ToolDeps): void;
