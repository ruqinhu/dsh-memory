export type MemoryTarget = 'memory' | 'user';
/**
 * Thrown instead of silently truncating.
 *
 * Truncation loses rules, which is exactly how a memory file quietly goes wrong:
 * the write looks successful and the next request is missing a constraint. The
 * inherited Hermes file is already 68% over its cap, so refusing the write is
 * what forces a real compression pass.
 */
export declare class CapExceededError extends Error {
    readonly target: MemoryTarget;
    readonly current: number;
    readonly cap: number;
    constructor(target: MemoryTarget, current: number, cap: number);
}
export declare function assertWithinCap(target: MemoryTarget, text: string, cap: number): void;
export interface CapReport {
    current: number;
    cap: number;
    percent: number;
    over: boolean;
}
export declare function capReport(text: string, cap: number): CapReport;
