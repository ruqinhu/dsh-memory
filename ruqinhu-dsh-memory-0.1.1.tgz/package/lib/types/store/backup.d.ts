/**
 * `YYYYMMDD_HHMMSS` in +08:00.
 *
 * The local offset is applied explicitly: a Saturday 01:30 +08:00 run would
 * otherwise be stamped with the previous UTC day, which makes rotation order and
 * human reading both misleading.
 */
export declare function stamp(date: Date): string;
/** Copy the memory documents into `backups/<stamp>/` and return that directory. */
export declare function backupMemories(memoryDir: string, at: Date): Promise<string>;
/** Keep only the newest `keep` backup directories. */
export declare function rotateBackups(root: string, keep: number): Promise<void>;
