import type { MemoryTarget } from './caps.js';
/**
 * Owns the two memory documents.
 *
 * Text is kept in memory because the injection seams are synchronous
 * (`systemPrompt.section({ text: fn })` and the `agent/pre-step` handler) while
 * file reads are not. Every write updates the cache and the file together, so
 * the two never disagree.
 */
export declare class MemoryFiles {
    private readonly dir;
    private readonly cache;
    constructor(dir: string);
    load(): Promise<void>;
    read(target: MemoryTarget): string;
    write(target: MemoryTarget, text: string): Promise<void>;
    path(target: MemoryTarget): string;
    directory(): string;
}
