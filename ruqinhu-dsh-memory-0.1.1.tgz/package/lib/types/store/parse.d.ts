/**
 * Split a memory document into trimmed, non-empty entries.
 *
 * The `§` separator is load-bearing: entries are complete rules, and a split
 * that drops blank fragments keeps a stray double separator from creating an
 * empty rule that then gets written back.
 */
export declare function splitEntries(text: string): string[];
/** Join entries with the canonical separator. The trailing newline is the writer's job. */
export declare function joinEntries(entries: readonly string[]): string;
