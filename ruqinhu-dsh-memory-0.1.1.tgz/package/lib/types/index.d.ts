import { Service, type Context } from '@deepseek-ai/cordis';
import { Config } from './config.js';
export declare const name = "memory";
export declare function expandTilde(path: string): string;
export default class Memory extends Service {
    config: Config;
    static inject: string[];
    static Config: import("@deepseek-ai/schemastery").default<Config>;
    private readonly memoryDir;
    private readonly caps;
    constructor(ctx: Context, config: Config);
}
